# Sorting Algorithms Package

This package provides implementations of various sorting algorithms including Bubble Sort, Insertion Sort, and Quick Sort.

## Installation

You can install the package using pip:

```bash
pip install siwp2005-yedija_gregorius-sort
